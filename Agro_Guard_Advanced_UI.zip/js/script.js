
function toggleMenu(){
document.querySelector(".nav-links").classList.toggle("show")
}

function drawNDVI(){

let canvas=document.getElementById("ndviCanvas")
if(!canvas) return

let ctx=canvas.getContext("2d")

for(let x=0;x<canvas.width;x+=10){
for(let y=0;y<canvas.height;y+=10){

let value=Math.random()

if(value>0.6) ctx.fillStyle="#1faa00"
else if(value>0.3) ctx.fillStyle="#9ccc65"
else ctx.fillStyle="#ff5252"

ctx.fillRect(x,y,10,10)

}
}

}

window.onload=drawNDVI
